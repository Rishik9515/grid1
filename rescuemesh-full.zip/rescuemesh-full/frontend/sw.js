/**
 * RescueMesh Service Worker v3
 * Handles: offline caching, background sync, push notifications
 */

const CACHE_NAME    = 'rescuemesh-v3';
const STATIC_ASSETS = [
    '/',
    '/index.html',
    '/real-dashboard.html',
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css',
    'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js',
    'https://cdn.socket.io/4.5.4/socket.io.min.js',
    'https://fonts.googleapis.com/css2?family=Russo+One&family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Barlow:wght@300;400;500;600&display=swap'
];

// ── Install ────────────────────────────────────────────────────────────────────
self.addEventListener('install', event => {
    console.log('[SW] Installing...');
    event.waitUntil(
        caches.open(CACHE_NAME).then(cache => {
            return cache.addAll(STATIC_ASSETS).catch(err => {
                console.warn('[SW] Some assets failed to cache:', err);
            });
        })
    );
    self.skipWaiting();
});

// ── Activate ──────────────────────────────────────────────────────────────────
self.addEventListener('activate', event => {
    console.log('[SW] Activating...');
    event.waitUntil(
        caches.keys().then(names =>
            Promise.all(
                names
                    .filter(name => name !== CACHE_NAME)
                    .map(name => {
                        console.log('[SW] Deleting old cache:', name);
                        return caches.delete(name);
                    })
            )
        )
    );
    self.clients.claim();
});

// ── Fetch ─────────────────────────────────────────────────────────────────────
self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);

    // Never cache socket.io or API POST calls
    if (url.pathname.startsWith('/socket.io/') ||
        (url.pathname.startsWith('/api/') && event.request.method !== 'GET')) {
        return;
    }

    // API GET: network first, fallback to cache
    if (url.pathname.startsWith('/api/')) {
        event.respondWith(
            fetch(event.request)
                .then(response => {
                    if (response.ok) {
                        const clone = response.clone();
                        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                    }
                    return response;
                })
                .catch(() => caches.match(event.request))
        );
        return;
    }

    // Static assets: cache first, network fallback
    event.respondWith(
        caches.match(event.request).then(cached => {
            if (cached) return cached;
            return fetch(event.request).then(response => {
                if (response && response.status === 200) {
                    const clone = response.clone();
                    caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
                }
                return response;
            }).catch(() => {
                // Offline fallback for HTML pages
                if (event.request.headers.get('accept')?.includes('text/html')) {
                    return caches.match('/index.html');
                }
            });
        })
    );
});

// ── Background Sync ───────────────────────────────────────────────────────────
self.addEventListener('sync', event => {
    console.log('[SW] Background sync:', event.tag);
    if (event.tag === 'sync-detections') {
        event.waitUntil(syncPendingDetections());
    }
});

async function syncPendingDetections() {
    try {
        const db      = await openIndexedDB();
        const pending = await getAllFromStore(db, 'pending-detections');
        console.log(`[SW] Syncing ${pending.length} pending detections...`);

        for (const detection of pending) {
            try {
                const response = await fetch('/api/detections', {
                    method:  'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body:    JSON.stringify(detection)
                });
                if (response.ok) {
                    await deleteFromStore(db, 'pending-detections', detection.id);
                    console.log('[SW] Synced detection:', detection.id);
                }
            } catch(err) {
                console.warn('[SW] Failed to sync detection:', err);
            }
        }
    } catch(err) {
        console.error('[SW] Sync error:', err);
    }
}

// ── Push Notifications ────────────────────────────────────────────────────────
self.addEventListener('push', event => {
    if (!event.data) return;
    const data = event.data.json();
    event.waitUntil(
        self.registration.showNotification(data.title || 'RescueMesh Alert', {
            body:    data.body || 'Detection received',
            icon:    '/icon.png',
            badge:   '/badge.png',
            tag:     data.tag || 'rescuemesh',
            data:    data,
            actions: [
                { action: 'view',    title: 'View Map' },
                { action: 'dismiss', title: 'Dismiss' }
            ]
        })
    );
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    if (event.action === 'view') {
        event.waitUntil(
            clients.openWindow('/dashboard')
        );
    }
});

// ── IndexedDB Helpers ─────────────────────────────────────────────────────────
function openIndexedDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('RescueMeshOffline', 1);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
        request.onupgradeneeded = e => {
            const db = e.target.result;
            if (!db.objectStoreNames.contains('pending-detections')) {
                db.createObjectStore('pending-detections', { keyPath: 'id' });
            }
            if (!db.objectStoreNames.contains('messages')) {
                db.createObjectStore('messages', { keyPath: 'id' });
            }
        };
    });
}

function getAllFromStore(db, storeName) {
    return new Promise((resolve, reject) => {
        const tx      = db.transaction(storeName, 'readonly');
        const request = tx.objectStore(storeName).getAll();
        request.onerror   = () => reject(request.error);
        request.onsuccess = () => resolve(request.result || []);
    });
}

function deleteFromStore(db, storeName, key) {
    return new Promise((resolve, reject) => {
        const tx      = db.transaction(storeName, 'readwrite');
        const request = tx.objectStore(storeName).delete(key);
        request.onerror   = () => reject(request.error);
        request.onsuccess = () => resolve();
    });
}
